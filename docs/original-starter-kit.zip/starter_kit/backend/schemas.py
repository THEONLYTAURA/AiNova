"""
Request/response models shared across routes.

Kept in one small file on purpose — R0 has ~5 endpoints. Split this up
only once it gets genuinely hard to scroll through, not before.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class DimensionScores(BaseModel):
    context: int
    task_clarity: int
    specificity: int
    constraints: int
    output_format: int
    examples: int
    evaluation: int


class EvaluationResult(BaseModel):
    """What the shared evaluation engine returns, regardless of which
    feature (Coach, Challenge, Skill Test question) called it."""

    session_id: str
    score: int
    level: str
    dimensions: DimensionScores
    dimension_evidence: dict[str, str]
    weaknesses: list[str]
    improved_prompt: str
    explanation: str
    lesson_dimension: str


class CoachRequest(BaseModel):
    session_id: str | None = Field(
        default=None, description="Omit on a user's first call; the API will create one."
    )
    prompt: str = Field(..., min_length=1, max_length=4000)


class ChallengeSubmitRequest(BaseModel):
    session_id: str | None = None
    challenge_id: str
    prompt: str = Field(..., min_length=1, max_length=4000)


class ChallengeOut(BaseModel):
    id: str
    title: str
    scenario: str
    category: str | None = None
    difficulty: str | None = None


class ProgressEvent(BaseModel):
    event_type: str
    score: int
    created_at: str


class ProgressResponse(BaseModel):
    events: list[ProgressEvent]
