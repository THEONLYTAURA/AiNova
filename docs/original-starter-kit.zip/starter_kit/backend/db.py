"""
Thin Supabase wrapper. Uses the SERVICE ROLE key because every write in R0
comes from this backend, never from the browser directly — see "Security
considerations" in 02_technical_architecture.md before that assumption
ever changes. If the frontend starts talking to Supabase directly (R1+),
turn Row Level Security back on first.
"""
from __future__ import annotations

import os

from supabase import Client, create_client

_url = os.environ["SUPABASE_URL"]
_key = os.environ["SUPABASE_SERVICE_ROLE_KEY"]

supabase: Client = create_client(_url, _key)


def get_or_create_session(session_id: str | None) -> str:
    """R0 has no login. The frontend generates a UUID, stores it in
    localStorage, and passes it on every call. This just makes sure a
    row exists for it (or makes a new one if the caller has none yet)."""
    if session_id:
        existing = supabase.table("sessions").select("id").eq("id", session_id).execute()
        if existing.data:
            supabase.table("sessions").update({"last_seen_at": "now()"}).eq(
                "id", session_id
            ).execute()
            return session_id

    created = supabase.table("sessions").insert({}).execute()
    return created.data[0]["id"]


def log_progress_event(session_id: str, event_type: str, score: int) -> None:
    """Every scored event (skill_test / coach / challenge) writes one row
    here. This one table is what draws the whole Progress chart — resist
    the urge to compute it by joining three differently-shaped tables."""
    supabase.table("progress_events").insert(
        {"session_id": session_id, "event_type": event_type, "score": score}
    ).execute()


def get_progress_events(session_id: str) -> list[dict]:
    result = (
        supabase.table("progress_events")
        .select("event_type, score, created_at")
        .eq("session_id", session_id)
        .order("created_at")
        .execute()
    )
    return result.data


def get_todays_challenge() -> dict | None:
    import datetime

    today = datetime.date.today().isoformat()
    result = (
        supabase.table("challenges").select("*").eq("active_date", today).limit(1).execute()
    )
    if result.data:
        return result.data[0]
    # Fallback: no challenge scheduled for today, serve any evergreen one.
    fallback = (
        supabase.table("challenges").select("*").is_("active_date", "null").limit(1).execute()
    )
    return fallback.data[0] if fallback.data else None
