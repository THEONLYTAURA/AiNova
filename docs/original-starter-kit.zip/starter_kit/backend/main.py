"""
PromptForge R0 API.

One FastAPI service. No queues, no websockets, no microservices — LLM
calls take 2-6 seconds and R0's traffic doesn't need anything fancier than
plain synchronous request/response. See 02_technical_architecture.md,
"what could become a bottleneck" for exactly when that stops being true.

Run locally:
    venv/bin/uvicorn main:app --reload --port 8000

Deploy: push this backend/ folder to Render as a Python web service with
start command `uvicorn main:app --host 0.0.0.0 --port $PORT`.
"""
from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

import db
from evaluation import evaluate_prompt
from schemas import ChallengeOut, ChallengeSubmitRequest, CoachRequest, EvaluationResult, ProgressResponse

limiter = Limiter(key_func=get_remote_address)

app = FastAPI(title="PromptForge API", version="0.1.0")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.environ.get("FRONTEND_ORIGIN", "http://localhost:5500")],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/session")
def create_session(session_id: str | None = None):
    """Idempotent: call with no id to get a new one, or with an existing
    id just to refresh last_seen_at."""
    return {"session_id": db.get_or_create_session(session_id)}


@app.post("/api/coach/evaluate", response_model=EvaluationResult)
@limiter.limit("20/hour")
def coach_evaluate(request: Request, payload: CoachRequest):
    if len(payload.prompt.strip()) < 3:
        raise HTTPException(400, "That prompt's too short to evaluate — try a full sentence.")

    session_id = db.get_or_create_session(payload.session_id)
    result = evaluate_prompt(payload.prompt)

    db.supabase.table("coach_submissions").insert(
        {
            "session_id": session_id,
            "submitted_prompt": payload.prompt,
            "overall_score": result["score"],
            "dimension_scores": result["dimensions"],
            "missing_elements": result["weaknesses"],
            "improved_prompt": result["improved_prompt"],
            "explanation": result["explanation"],
            "lesson_dimension": result["lesson_dimension"],
        }
    ).execute()
    db.log_progress_event(session_id, "coach", result["score"])

    return {**result, "session_id": session_id}


@app.get("/api/challenge/today", response_model=ChallengeOut)
def challenge_today():
    challenge = db.get_todays_challenge()
    if not challenge:
        raise HTTPException(404, "No challenge available — seed the challenges table.")
    return challenge


@app.post("/api/challenge/submit", response_model=EvaluationResult)
@limiter.limit("20/hour")
def challenge_submit(request: Request, payload: ChallengeSubmitRequest):
    session_id = db.get_or_create_session(payload.session_id)

    challenge = (
        db.supabase.table("challenges").select("scenario").eq("id", payload.challenge_id).execute()
    )
    if not challenge.data:
        raise HTTPException(404, "Unknown challenge_id.")

    result = evaluate_prompt(payload.prompt, task_context=challenge.data[0]["scenario"])

    db.supabase.table("challenge_submissions").insert(
        {
            "session_id": session_id,
            "challenge_id": payload.challenge_id,
            "submitted_prompt": payload.prompt,
            "overall_score": result["score"],
            "dimension_scores": result["dimensions"],
            "feedback": result["explanation"],
        }
    ).execute()
    db.log_progress_event(session_id, "challenge", result["score"])

    return {**result, "session_id": session_id}


@app.get("/api/progress", response_model=ProgressResponse)
def progress(session_id: str):
    return {"events": db.get_progress_events(session_id)}
