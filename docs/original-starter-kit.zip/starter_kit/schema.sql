-- PromptForge R0 schema (Postgres / Supabase)
-- Run in the Supabase SQL editor, or `supabase db push` if you're using the CLI.
--
-- Design notes (see 02_technical_architecture.md for the full reasoning):
--  * No `users` table in R0 on purpose. Accounts are an R1 feature. `sessions`
--    is an anonymous identity the frontend generates and stores in
--    localStorage; add a `user_id` column here later and backfill it once
--    real accounts exist — don't build that path now.
--  * `progress_events` is a single append-only log that every feature writes
--    to. It's what the Progress screen reads. Resist joining
--    skill_test_attempts + coach_submissions + challenge_submissions with
--    different shapes just to draw one line chart.
--  * RLS is left OFF: in R0, only this backend (using the service-role key)
--    ever talks to Supabase. Turn RLS on in R1, the moment the frontend
--    starts calling Supabase directly for anything.

create extension if not exists pgcrypto;

create table if not exists sessions (
  id uuid primary key default gen_random_uuid(),
  email text,                              -- set only if the user chooses "save my progress"
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table if not exists skill_test_attempts (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  overall_score integer,                   -- 0-100, computed server-side (equal-weighted across 10 questions)
  level text,                              -- e.g. 'AI Practitioner'
  dimension_scores jsonb,                  -- one entry per of the 10 skill-test competencies
  weaknesses jsonb
);

create table if not exists skill_test_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references skill_test_attempts(id) on delete cascade,
  question_id text not null,               -- key into the question bank, which lives in code, not the DB
  question_type text not null check (question_type in ('prompt_write', 'scenario_mcq')),
  answer_text text,                        -- the prompt they wrote, or the option id they picked
  score integer,                           -- 0-100 for this single question
  dimension text,                          -- which of the 10 competencies this question targets
  created_at timestamptz not null default now()
);

create table if not exists coach_submissions (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  submitted_prompt text not null,
  overall_score integer not null,
  dimension_scores jsonb not null,
  missing_elements jsonb,
  improved_prompt text,
  explanation text,
  lesson_dimension text,
  created_at timestamptz not null default now()
);

create table if not exists challenges (
  id uuid primary key default gen_random_uuid(),
  title text not null unique,              -- unique so seed data can be re-run safely; relax if that ever gets in the way
  scenario text not null,                  -- the task the user is asked to write a prompt for
  category text,                           -- 'study' | 'work' | 'career' | ...
  difficulty text check (difficulty in ('easy', 'medium', 'hard')),
  active_date date,                        -- the day this is "today's" challenge; null = evergreen pool
  created_at timestamptz not null default now()
);

create table if not exists challenge_submissions (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  challenge_id uuid not null references challenges(id),
  submitted_prompt text not null,
  overall_score integer not null,
  dimension_scores jsonb not null,
  feedback text,
  created_at timestamptz not null default now()
);

create table if not exists lessons (
  id text primary key,                     -- e.g. 'specificity', 'constraints'
  title text not null,
  content_md text not null,
  sort_order integer not null default 0
);

create table if not exists progress_events (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  event_type text not null check (event_type in ('skill_test', 'coach', 'challenge')),
  score integer not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_progress_events_session on progress_events(session_id, created_at);
create index if not exists idx_coach_submissions_session on coach_submissions(session_id, created_at);
create index if not exists idx_challenge_submissions_session on challenge_submissions(session_id, created_at);
create index if not exists idx_skill_test_attempts_session on skill_test_attempts(session_id, started_at);

-- ---------------------------------------------------------------------
-- Seed data — enough to demo the product on day one. Delete or replace
-- freely; nothing in the app logic depends on these specific rows.
-- ---------------------------------------------------------------------

insert into lessons (id, title, content_md, sort_order) values
  ('context', 'Give the AI a situation, not just a request', 'A prompt with context tells the AI who the output is for and why. "Write a CV" forces the model to guess your industry, experience level, and the job you want. "Write a CV for a final-year IT student applying for a junior developer role" gives it something real to work with.', 1),
  ('task_clarity', 'Say exactly what you want done', 'Vague verbs like "help with" or "look at" leave the actual task undefined. Replace them with a concrete action: summarise, rewrite, compare, classify, generate.', 2),
  ('specificity', 'Concrete beats general', 'Numbers, names, and constraints remove guesswork. "Make it shorter" is a suggestion; "cut it to 150 words" is an instruction.', 3),
  ('constraints', 'Set the boundaries up front', 'Tone, length, audience, and things to avoid are all constraints. Stating them in the prompt is cheaper than fixing them after a bad first draft.', 4),
  ('output_format', 'Tell it how to hand the answer back', 'A table, a numbered list, JSON, three bullet points — specifying the shape of the output saves you a reformatting pass every time.', 5),
  ('examples', 'Show, don''t just tell', 'One good example of the output you want teaches the model your standard faster than another paragraph of instructions.', 6),
  ('evaluation', 'Ask it to check its own work', 'Prompts that ask the AI to state its assumptions, flag uncertainty, or verify facts catch more mistakes before you see the output.', 7)
on conflict (id) do nothing;

insert into challenges (title, scenario, category, difficulty, active_date) values
  ('Lecture notes to study guide', 'You need AI to turn messy, unstructured lecture notes into a clean study guide with headings and a short quiz at the end. Write the best prompt you can.', 'study', 'easy', current_date),
  ('CV bullet points that actually land', 'You want AI to rewrite three flat CV bullet points into achievement-focused ones with metrics, without inventing facts that aren''t true. Write the prompt.', 'career', 'medium', null),
  ('Client email, softened but still clear', 'You need to tell a client a deadline is slipping by a week, without sounding like you''re making excuses. Write the prompt you''d give an AI to draft that email.', 'work', 'medium', null)
on conflict (title) do nothing;
