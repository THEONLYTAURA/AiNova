# PromptForge R0 — starter kit

This is a working starting point for the R0 backend, not a toy demo. Every
piece here has actually been run:

- `schema.sql` has been executed against a real Postgres 16 database —
  all 8 tables, 4 indexes, and the seed data (7 lessons, 3 challenges)
  create cleanly, and it's safe to re-run (no duplicate rows on a second
  run).
- `backend/` boots with FastAPI's TestClient, and `/api/coach/evaluate`
  was exercised end-to-end with the OpenAI and Supabase calls mocked —
  request in, session created, composite score computed, response
  validated against the schema, all wired correctly.
- `backend/test_evaluation.py` proves the scoring math itself: the
  weighted composite matches a hand-calculated example, the level bands
  cover 0-100 with no gaps or overlaps, scores clamp correctly at the
  extremes, and a prompt-injection attempt gets scored (not obeyed).

What's still on you: a real `OPENAI_API_KEY` and `SUPABASE_URL` /
`SUPABASE_SERVICE_ROLE_KEY`, since this sandbox can't reach either
service. Everything downstream of "the API call returns valid JSON" has
been checked; the API call itself you'll verify the first time you run
it for real.

## Setup

1. **Database.** Create a free Supabase project, open the SQL editor, and
   run `schema.sql` in this folder. Takes under a minute.

2. **Backend.**
   ```bash
   cd backend
   python3 -m venv venv
   ./venv/bin/pip install -r requirements.txt
   cp .env.example .env   # then fill in your real keys
   ./venv/bin/uvicorn main:app --reload --port 8000
   ```
   Visit `http://localhost:8000/docs` for interactive API docs (FastAPI
   generates this automatically from `schemas.py`).

3. **Sanity-check the evaluation logic without spending a cent:**
   ```bash
   OPENAI_API_KEY=dummy ./venv/bin/python test_evaluation.py
   ```
   This never calls OpenAI — it fakes the API response and checks the
   scoring math is right. Run it again any time you touch `evaluation.py`.

4. **Frontend.** Not included yet — R0's frontend is plain HTML/CSS/JS
   per the stack decision in `02_technical_architecture.md`, and it's a
   natural next thing to build once you've confirmed the API works
   against your own OpenAI key. The API is designed to be called with
   `fetch()` from a static page with no build step.

## File map

```
schema.sql                  Full DB schema + seed data (lessons, sample challenges)
backend/
  main.py                   FastAPI app — 6 routes, that's the whole R0 API
  evaluation.py              The shared scoring engine (Coach, Challenge, Skill Test)
  db.py                      Thin Supabase wrapper
  schemas.py                 Request/response models
  test_evaluation.py         Unit tests for the scoring math (no API calls)
  requirements.txt           Pinned, tested versions
  .env.example               Every secret the backend needs, documented
```

## Before you deploy this anywhere public

Read "Security considerations" in `02_technical_architecture.md` first —
in particular: never ship the `SUPABASE_SERVICE_ROLE_KEY` or
`OPENAI_API_KEY` to the browser, and don't relax the rate limits on
`/api/coach/evaluate` and `/api/challenge/submit` without a plan for what
happens if someone scripts a loop against them.
